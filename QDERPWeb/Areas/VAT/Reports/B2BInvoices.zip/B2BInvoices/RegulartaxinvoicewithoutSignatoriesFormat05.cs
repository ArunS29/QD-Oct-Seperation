﻿namespace QD.ERP.Web.Areas.VAT.Reports.B2BInvoices
{
    public partial class RegulartaxinvoicewithoutSignatoriesFormat05 : DevExpress.XtraReports.UI.XtraReport
    {
        public RegulartaxinvoicewithoutSignatoriesFormat05()
        {
            InitializeComponent();
        }
    }
}
