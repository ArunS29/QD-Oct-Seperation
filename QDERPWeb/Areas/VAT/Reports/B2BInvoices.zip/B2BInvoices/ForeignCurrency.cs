﻿namespace QD.ERP.Web.Areas.VAT.Reports.B2BInvoices
{
    public partial class ForeignCurrency : DevExpress.XtraReports.UI.XtraReport
    {
        public ForeignCurrency()
        {
            InitializeComponent();
        }

        private void ForeignCurrency_BeforePrint(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }
    }
}
