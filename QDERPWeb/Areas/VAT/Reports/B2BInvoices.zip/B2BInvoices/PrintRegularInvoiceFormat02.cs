﻿namespace QD.ERP.Web.Areas.VAT.Reports.B2BInvoices
{
    public partial class PrintRegularInvoiceFormat02 : DevExpress.XtraReports.UI.XtraReport
    {
        public PrintRegularInvoiceFormat02()
        {
            InitializeComponent();
        }
    }
}
