﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace QD.ERP.Web.Areas.Finance.Reports.Cost_Analysis.Detailed_Report
{
	public partial class DetailedBydate : DevExpress.XtraReports.UI.XtraReport
	{	
		public DetailedBydate()
		{
			InitializeComponent();
		}
	}
}
